package com.fastertable.fastertable.data

data class Payment(
    val id: String,
    val orderId: String,
    val orderNumber: Int,
    val tableNumber: Int,
    val timeStamp: Long,
    val orderStartTime: Long,
    val orderCloseTime: Long?,
    val orderType: String,
    val guestCount: Int,
    val splitType: String,
    val splitTicket: Int,
    val employeeId: String,
    val userName: String,
    val tickets: ArrayList<Ticket>,
    val terminalId: String,
    val statusApproval: String,
    val newApproval: Approval,
    val closed: Boolean,
    val locationId: String,
    val archived: Boolean,
    val type: String,
    val _rid: String?,
    val _self: String?,
    val _etag: String?,
    val _attachments: String?,
    val _ts: Long?
)

data class Ticket(
    val orderId: String,
    val id: Int,
    val ticketItems: ArrayList<TicketItem>,
    val subTotal: Double,
    val tax: Double,
    val total: Double,
    val paymentType: String,
    val gratuity: Double,
    val deliveryFee: Double,
    val paymentTotal: Double?,
    val stageResponse: ArrayList<StageResponse>,
    val creditCardTransactions: ArrayList<CreditCardTransaction>,
    val partialPayment: Boolean,

)

data class CreditCardTransaction(
    val ticketId: Int,
    val creditTotal: Double?,
    val captureTotal: Double?,
    val refundTotal: Double?,
    val voidTotal: Double?,
    val creditTransaction: CayanTransaction,
    val captureTransaction: TransactionResponse45,
    val refundTransaction: TransactionResponse45,
    val voidTransaction: TransactionResponse45,
)

data class TicketItem(
    val id: Int,
    val orderGuestNo: Int,
    val orderItemId: Int,
    val quantity: Int,
    val itemName: String,
    val itemSize: String,
    val itemPrice: Double,
    val discountPrice: Double,
    val priceModified: Boolean,
    val itemMods: ArrayList<ModifierItem>,
    val salesCategory: String,
    val ticketItemPrice: Double,
    val tax: Double,
)

data class PaymentTransaction(
    val paymentType: String,
    val splitType: String,
    val checkTotal: Double,
    val amountTendered: Double,
    val amountPaid: Double,
    val paidInFull: Boolean,
)

data class ManagerApproval(
    val id: String,
    val order: Order,
    val approvalItem: ApprovalItem,
    val timeRequested: Long,
    val approved: Boolean?,
    val timeHandled: Long,
    val managerId: String,
    val locationId: String,
    val archived: Boolean,
    val type: String,
    val _rid: String?,
    val _self: String?,
    val _etag: String?,
    val _attachments: String?,
    val _ts: Long?

)

data class Approval(
    val id: String,
    val order: Order,
    val approvalItems: ArrayList<ApprovalItem>,
    val timeRequested: Long,
    val type: String,
    val _rid: String?,
    val _self: String?,
    val _etag: String?,
    val _attachments: String?,
    val _ts: Long?
)

data class ApprovalItem(
    val id: Int,
    val approvalType: String, //Price, Discount, Discount Ticket, Void Item, Void Order
    val discount: String,
    val ticketItem: TicketItem,
    val ticket: Ticket,
    val amount: Double,
    val timeRequested: Long,
    val approved: Boolean?,
    val timeHandled: Long,
    val managerId: String,
)

data class TicketItemSelected(
    val item: TicketItem,
    val selected: Boolean
)

data class TicketItemChosen(
    val ticketId: Int,
    val itemId: Int,
    val guestNo: Int,
)

data class TicketSelected(
    val item: Ticket,
    val selected: Boolean
)

data class processPay(
    val order: Order,
    val payment: Payment,
    val ticket: Ticket,
    val changeDue: Double,
)

data class SortedTicket (
    val p: Payment,
    val t: Ticket,
)

data class PaymentTickets (
    val p: Payment,
    val t: Ticket,
    val ticketDate: Long,
)

data class adHocMove(
    val type: String,
    val guest: Guest,
    val item: OrderItem,
)

data class MobileCredit(
    val ipAddress: String,
    val printer: Printer,
)

data class UserTicketUpdate(
    val t: Ticket,
    val n: Int,
)

data class MonthRequest(
    val locationId: String,
    val month: Int,
    val year: Int,
    val timeZone: Int,
)

data class SalesSummary(
    val sales: Double,
    val cash: Double,
    val credit: Double,
    val guests: Int,
    val tips: Double,
    val averageTip: Double,
    val salesTax: Double,
    val grossSales: Double,
)

enum class CreditTransactionType {
    SALE,
    PREAUTH
}

data class ModifyPrice(
    val t: TicketItem,
    val price: Double
)

data class ticketAmount(
    val amount: Double,
)

data class secretKey(
    val key: String,
)

data class stripePayment(
    val token: String,
)

//data class paymentIntent(
//val id: String,
//val object: any,
//val amount: number,
//val amount_capturable: number,
//val amount_received: number,
//val application: any,
//val application_fee_amount: any,
//val canceled_at: any,
//val cancellation_reason: String,
//val capture_method: any,
//val charges: (
//val object: any,
//val data: [],
//val has_more: Boolean,
//val url: String,
//),
//val client_secret: String,
//val confirmation_method: any,
//val created: any,
//val currency: String,
//val customer: any,
//val description: String,
//val invoice: any,
//val last_payment_error: any,
//val livemode: Boolean,
//val metadata: (),
//val next_action: any,
//val on_behalf_of: any,
//val payment_method: any,
//val payment_method_options: (
//val card: (
//val val installments: any,
//val val network: any,
//val val request_three_d_secure: any
//val )
//),
//val payment_method_types: [],
//val receipt_email: String,
//val review: any,
//val setup_future_usage: any,
//val shipping: any,
//val statement_descriptor: any,
//val statement_descriptor_suffix: any,
//val status: any,
//val transfer_data: any,
//val transfer_group: any
//)

data class PayTicket(
    val p: Payment,
    val t: Ticket
)

data class CaptureTicket(
    val p: Payment,
    val t: Ticket,
    val cc: CreditCardTransaction
)

data class OrderPayTicket(
    val op: OrderPayment,
    val t: Ticket
)

data class OrderPayTID(
    val op: OrderPayment,
    val ti: Int,
)