package com.fastertable.fastertable.data

data class ReportDateRange (
    val startDate: Long,
    val endDate: Long,
)

data class MessageDialogData(
        val continueX: Boolean,
        val message: String,
)

data class HourMinute (
        val hour: Int,
        val minute: Int,
)

data class DeletePrinterDialogData(
        val deletedPrinter: Printer,
        val printers: ArrayList<Printer>,
        val continueX: Boolean,
        val message: String,
)