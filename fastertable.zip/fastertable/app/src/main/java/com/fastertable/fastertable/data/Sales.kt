package com.fastertable.fastertable.data

data class PaymentSelected (
    val payment: Payment,
    val selected: Boolean
)

data class Refund (
        val t: PayTicket,
        val amount: Double
)