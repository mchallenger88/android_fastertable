package com.fastertable.fastertable.data

enum class PaymentType {
    VISA,
    MASTERCARD,
    AMEX,
    DISCOVER,
    DEBIT,
    GIFT,
    EBT,
    LEVELUP,
    VOYAGER,
    WEX,
    JCB,
    CUP,
    UNKNOWN
}

enum class EntryType{
    SWIPE,
    PROXIMITY,
    BARCODE,
    MANUAL
}

enum class TransactionType{
    SALE,
    AUTHORIZATION,
    REFUND,
    ADDVALUE,
    BALANCEINQUIRY
}

enum class ResponseType{
    SINGLE,
    MULTI,
    COMPOUND
}

data class CayanCardTransaction (
    val merchantName: String,
    val merchantSiteId: String,
    val merchantKey: String,
    val request: Request,
    val requestWithTip: RequestWithTip,
)

data class Request(
    val transactionType: String,
    val amount: Double,
    val clerkId: String,
    val orderNumber: String,
    val dba: String,
    val softwareName: String = "fastertable",
    val softwareVersion: String = "1.18.0.0",
    val transactionId: String,
    val forceDuplicate: Boolean,
    val taxAmount: Double,
    val terminalId: String,
    val ticketItems: TransactionDetails,
    val enablePartialAuthorization: Boolean,
)

data class RequestWithTip(
    val transactionType: String,
    val amount: Double,
    val clerkId: String,
    val orderNumber: String,
    val dba: String,
    val softwareName: String = "fastertable",
    val softwareVersion: String = "1.18.0.0",
    val transactionId: String,
    val forceDuplicate: Boolean,
    val taxAmount: Double,
    val tipDetails: TipDetails,
    val terminalId: String,
    val ticketItems: TransactionDetails,
    val enablePartialAuthorization: Boolean,
)

data class TransactionDetails(
    val ticketItems: ArrayList<TicketItem>
)

data class TipDetails(
    val eligibleAmount: Double,
)

data class StageResponse(
    val transportKey: String,
    val validationKey: String,
    val messages: String,
)

data class TerminalResponse(
    val status: String,
    val responseMessage: String,
    val additionalParameters: String,
)

data class GiftTerminalResponse(
    val Status: String,
    val responseMessage:String,
    val additionalParameters: String,
)

data class MessageList(
    val field: String,
    val information: String,
)

data class CayanTransaction(
    val AccountNumber: String,
    val AdditionalParameters: AdditionalParameters,
    val AmountApproved: String,
    val AuthorizationCode: String,
    val Cardholder: String,
    val EntryMode: String,
    val ErrorMessage: String,
    val PaymentType: String,
    val ResponseType: String,
    val Status: String,
    val TipDetails: TipDetails,
    val Token: String,
    val TransactionDate: String?,
    val TransactionType: String,
    val ValidationKey: String,
)

data class EMV(
    val ApplicationInformation: ApplicationInformation,
    val cardInformation: CardInformation,
    val applicationCryptogram: ApplicationCryptogram,
    val cvmResults: String,
    val issuerApplicationData: String,
    val terminalVerificationResults: String,
    val unpredictableNumber: String,
    val amount: Amount,
    val posEntryMode: String?,
    val terminalInformation: TerminalInformation,
    val transactionInformation: TransactionInformation,
    val cryptogramInformationData: String,
    val PINStatement: String,
    val cvmMethod: String,
    val issuerActionCodeDefault: String,
    val issuerActionCodeDenial: String,
    val issuerActionCodeOnline: String,
    val authorizationResponseCode: String,
)

data class ApplicationInformation(
    val Aid: String,
    val ApplicationLabel: String,
    val applicationExpiryDate: String?,
    val applicationEffectiveDate: String?,
    val applicationInterchangeProfile: String,
    val applicationVersionNumber: String,
    val applicationTransactionCounter: String,
    val applicationUsageControl: String,
    val applicationPreferredName: String,
    val applicationDisplayName: String,
)

data class CardInformation(
    val maskedPan: String,
    val panSequenceNumber: String,
    val cardExpiryDate: String?,
)

data class ApplicationCryptogram(
    val cryptogramType: String,
    val cryptogram: String,
)

data class Amount(
    val amountAuthorized: Double,
    val amountOther: Double,
)

data class TerminalInformation(
    val terminalType: String,
    val ifdSerialNumber: String,
    val terminalCountryCode: String,
    val terminalID: String,
    val terminalActionCodeDefault: String,
    val terminalActionCodeDenial: String,
    val terminalActionCodeOnline: String,
)

data class TransactionInformation(
    val transactionType: String,
    val transactionCurrencyCode: String,
    val transactionStatusInformation: String,
)

data class AdditionalParameters(
    val AmountDetails: AmountDetails,
    val SignatureData: String,
    val EBTDetails: EBTDetails?,
    val KeyedDetails: KeyedDetails?,
    val Loyalty: Loyalty?,
    val Survey: Survey?,
    val DebitTraceNumber: String?,
    val EMV: EMV,
)


data class AmountDetails(
    val Cashback: String,
    val Discount: String?,
    val Donation: String,
    val RemainingCardBalance: String,
    val Surcharge: String,
    val UserTip: String,
)

data class EBTDetails(
    val EBTType: String,
    val FnsId: String,
    val Balances: Balances
)

data class Balances (
    val CashAvailableBalance: Double,
    val SnapAvailableBalance: Double,
    val PointsBalance: Double?,
    val AmountBalance: Double?
)

data class KeyedDetails(
    val ExpirationDate: String?,
    val AvsStreetZipCode: String,
    val AvsResponse: String,
    val CvResponse: String,
)

data class Loyalty(
    val AccountNumber: String,
    val Balances: Balances
)

data class Survey(
    val MerchantMessage: String,
    val CustomerMessage: String
)

data class MerchantCredentials(
    val MerchantName: String,
    val MerchantSiteId: String,
    val MerchantKey: String,
    val webAPIKey: String,
    val stripePrivateKey: String,
    val stripePublickey: String,
)

data class TipRequest(
    val Token: String,
    val Amount: Double,
)

data class CaptureRequest(
    val Credentials: MerchantCredentials,
    val Capture: Capture,
)

data class AuthorizationRequest(
    val Credentials: MerchantCredentials,
    val PaymentData: AuthPaymentData,
    val Request: AuthRequestData,
)

data class WebAuthorizationRequest(
    val Credentials: MerchantCredentials,
    val PaymentData: WebAuthPaymentData,
    val Request: WebAuthRequestData
)

data class AuthPaymentData(
    val source: String,
    val cardNumber: String,
    val expirationDate: String,
    val cardHolder: String,
    val avsStreetAddress: String,
    val avsZipCode: String,
    val cardVerificationValue: String,
)

data class WebAuthPaymentData(
    val Source: String,
    val VaultToken: String,
)

data class WebAuthRequestData(
    val Amount: Double,
    val InvoiceNumber: String,
    val registerNumber: String,
    val merchantTransactionId: String,
    val cardAcceptorTerminalId: String,
    val CustomerEmailAddress: String,
)

data class AuthRequestData(
    val amount: Double,
    val invoiceNumber: String,
    val registerNumber: String,
    val merchantTransactionId: String,
    val cardAcceptorTerminalId: String,

)

data class Capture(
    val Token: String,
    val Amount: Double,
    val InvoiceNumber: String,
    val RegisterNumber: String,
    val MerchantTransactionId: String,
    val CardAcceptorTerminalId: Int,
)

data class TransactionResponse45(
    val ApprovalStatus: String,
    val Token: String,
    val AuthorizationCode: String,
    val TransactionDate: String,
    val Amount: Double,
    val RemainingCardBalance: Double,
    val CardNumber: String,
    val Cardholder: String,
    val CardType: String,
    val FsaCard: String,
    val ReaderEntryMode: String,
    val AvsResponse: String,
    val CvResponse: String,
    val ErrorMessage: String,
    val ExtraData: String,
    val FraudScoring: String,
    val Rfmiq: String,
)

data class RefundRequest(
    val credentials: MerchantCredentials,
    val paymentData: PaymentData,
    val request: RefundRequestData,
)

data class PaymentData(
    val source: String,
    val token: String,
)

data class RefundRequestData(
    val amount: Double,
    val invoiceNumber: String,
    val registerNumber: String,
    val merchantTransactionId: String,
    val cardAcceptorTerminalId: String,
)

data class LineItem(
    val commodityCode: String,
    val description: String,
    val upc: String,
    val quantity: Int,
    val unitOfMeasure: String,
    val unitCost: Double,
    val discountAmount: Double,
    val totalAmount: Double,
    val taxAmount: Double,
    val extendedAmount: Double,
    val debitOrCreditIndicator: String,
    val netOrGrossIndicator: String,
)

data class DetailsTransportKeyRequest(
    val name: String,
    val siteID: String,
    val key: String,
    val transportKey: String,
)

data class DetailsTransportKeyResponse(
    val status: String,
    val errorMessage: String,
    val totalAmountApproved: String,
    val requestedAmount: String,
    val responseType: String,
    val paymentDetails: PaymentDetails,

)

data class PaymentDetails(
    val paymentDetail: PaymentDetail,
)

data class PaymentDetail(
    val paymentType: String,
    val status: String,
    val errorMessage: String,
    val transactionType: String,
    val token: String,
    val authorizationCode: String,
    val customer: String,
    val email: String,
    val phoneNumber: String,
    val accountNumber: String,
    val expirationDate: String,
    val entryMode: String,
    val transactionDate: String,
    val amountDetail: AmountDetail,
    val signatureDetail: SignatureDetail,
    val giftDetail: GiftDetail,
    val loyaltyDetail: LoyaltyDetail,
    val additionalResponseParameters: AdditionalResponseParameters,
)

data class AmountDetail(
    val amountApproved: String,
    val amountCharged: String,
    val taxAmount: String,
    val tipAmount: String,
    val userTipAmount: String,
    val discountAmount: String,
    val voucherAmount: String,
    val remainingCardBalance: String,
)

data class SignatureDetail(
    val signatureType: String,
    val signature: String,
)

data class GiftDetail(
    val balance: String,
)

data class LoyaltyDetail(
    val visits: String,
    val lastVisit: String,
    val lifetimeSpend: String,
)

data class AdditionalResponseParameters(
    val fsaCard: String,
)

data class AdjustTip(
    val credentials: MerchantCredentials,
    val tipRequest: TipRequest,
)

data class PaymentIntentRequest(
    val key: String,
    val payment: Payment,
)