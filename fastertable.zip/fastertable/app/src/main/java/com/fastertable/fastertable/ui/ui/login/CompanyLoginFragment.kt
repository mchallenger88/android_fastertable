package com.fastertable.fastertable.ui.ui.login

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.fastertable.fastertable.R
import com.fastertable.fastertable.ui.ui.home.HomeViewModel

class CompanyLoginFragment : Fragment()  {

    private lateinit var viewModel: CompanyLoginViewModel

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        viewModel =
                ViewModelProvider(this).get(CompanyLoginViewModel::class.java)
        val root = inflater.inflate(R.layout.company_login_fragment, container, false)


        return root
    }
}