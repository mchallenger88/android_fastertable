package com.fastertable.fastertable.ui.ui.login

class UserLoginFragment {
}