package com.fastertable.fastertable.data

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class MenuItem(
     val id: String,
     val itemName: String,
     val itemDescription: String,
     val prices: ArrayList<ItemPrice>,
     val modifiers: ArrayList<Modifier>,
     val ingredients: ArrayList<ItemIngredient>,
     val active: Boolean,
     val printer: Printer,
     val prepStation: PrepStation,
     val salesCategory: String,
     val kiosk: Boolean,
     val imageName: String,
     val categories: ArrayList<String>,
     val soldOut: Boolean,
     val alias: String,
     val avatar: String,
     val type: String,
     val _rid: String?,
     val _self: String?,
     val _etag: String?,
     val _attachments: String?,
     val _ts: Long?
): Parcelable

@Parcelize
data class ItemPrice(
    val size: String,
    val price: Double,
    val discountPrice: Double,
    val tax: String
): Parcelable

@Parcelize
data class ItemIngredient(
     val name: String,
     val surcharge: Double,
     val orderValue: Int,
): Parcelable

@Parcelize
data class MenuCategory(
     val id: String,
     val category: String,
     val displayOrder: Int,
     val menuItems: ArrayList<MenuItem>,
     val kioskDisplay: Boolean?,
     val imageName: String,
): Parcelable

data class MenuItemSummary(
     val id: String,
     val name: String,
     val modifiers: ArrayList<String>,
)

data class MenuItemMenus
(
     val id: String,
     val name: String,
)

data class IngredientList(
     val id: String,
     val locationId: String,
     val ingredients: ArrayList<String>,

)

@Parcelize
data class Modifier(
     val id: String,
     val modifierName: String,
     val purpose: String,
     val modifierItems: ArrayList<ModifierItem>,
     val selectionLimitMin: Int,
     val selectionLimitMax: Int,
     val active: Boolean,
     val type: String,
     val _rid: String?,
     val _self: String?,
     val _etag: String?,
     val _attachments: String?,
     val _ts: Long?
): Parcelable

@Parcelize
data class ModifierItem(
     val itemName: String,
     val surcharge: Double,
): Parcelable

data class SalesCategory(
     val name: String,
     val taxCategory: TaxCategory,
)

data class TaxCategory(
     val id: String,
     val taxCategoryName: String,
     val taxCategoryPercentage: Double,
)

data class modValid(
     val modName: String,
     val valid: Boolean,
)

enum class IngredientToggle {
    NONE,
    NORMAL,
    EXTRA
}

data class addItemMenuCat(
     val menu: String,
     val category: String
)

data class DeleteRequest(
     val id: String,
     val locationId: String
)

data class IngredientChange(
     val item: ItemIngredient,
     val value: Double,
)

data class OrderOrderItem(
     val order:Order,
     val orderItem: OrderItem,
)

data class MenuLocation(
     val menuName: String,
     val categories: ArrayList<MenuCategory>,
     val catNames: ArrayList<String>,
)