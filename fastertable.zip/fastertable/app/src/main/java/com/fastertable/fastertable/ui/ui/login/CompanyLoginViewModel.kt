package com.fastertable.fastertable.ui.ui.login

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fastertable.fastertable.data.Company
import kotlinx.coroutines.launch


class CompanyLoginViewModel(application: Application) : AndroidViewModel(application) {
    private val app: Application = application

    private val _company = MutableLiveData<Company>()
    val company: LiveData<Company>
        get() = _company

    private val _loginName = MutableLiveData<String>()
    val loginName: LiveData<String>
        get() = _loginName

    private val _password = MutableLiveData<String>()
    val password: LiveData<String>
        get() = _password

    init{
        checkCompany()
    }

    @SuppressLint("CommitPrefEdits")
    private fun saveCompany(){
        viewModelScope.launch {
            //getting shared preferences
            val sp: SharedPreferences = app.getSharedPreferences("company_login", MODE_PRIVATE)
            //initializing editor
            val editor = sp.edit()
            editor.putString("loginName", loginName.value);
            editor.putString("password", password.value);
            editor.apply();

            //TODO: Save company json to file
        }
    }

    @SuppressLint("CommitPrefEdits")
    private fun checkCompany(){
        //getting shared preferences
        val sp: SharedPreferences = app.getSharedPreferences("company_login", MODE_PRIVATE)
        //initializing editor
        _loginName.value = sp.getString("loginName", "")
        _password.value = sp.getString("password", "")
    }
}