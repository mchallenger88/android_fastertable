package com.fastertable.fastertable.data

data class User
(
    val id: String,
    val pin: String,
    val backOfficePIN: String, //for Employees, Settings and Payroll
    val userName: String,
    val locked: Boolean,
    val permissions: ArrayList<Permission>,
    val locationId: String,
)

data class Permission(
    val name: String,
    val displayName: String,
    val value: Boolean,
    val type: String,
)

data class OpsAuth
(
    val userName: String,
    val employeeId: String,
    val employeeName: String,
    val bearerToken: String,
    val isAuthenticated: Boolean,
    val userClock: UserClock,
    val claims: ArrayList<UserClaim>,
    val companies: ArrayList<Company>,
    val locations: ArrayList<Location>,
)

data class UserClaim(
    val claimId: String,
    val UserId: String,
    val permission: Permission,
)

data class UserClock(
    val employeeId: String,
    val clockInTime: Long,
    val clockOutTime: Long,
    val checkout: Boolean,
    val checkoutApproved: Boolean,
)

data class ClockOutCredentials
(
    val employeeId: String,
    val companyId: String,
    val locationId: String,
    val time: Long,
    val midnight: Long,
)

data class PinClockOutCredentials
(
    val pin: String,
    val companyId: String,
    val locationId: String,
    val time: Long,
    val midnight: Long,
)

data class CheckoutCredentials(
    val employeeId: String,
    val companyId: String,
    val locationId: String,
    val checkout: Boolean,
    val midnight: Long,
)

data class OpsUser(
    val firstName: String,
    val lastName: String,
    val email: String,
    val password: String,
    val salt: String,
    val companies: ArrayList<Company>,
    val locations: ArrayList<Location>,
    val cos: ArrayList<String>,
    val locs: ArrayList<String>,
    val claims: ArrayList<UserClaim>,
    val permissions: ArrayList<Permission>,
    val locationId: String,
    val archived: Boolean,
    val type: String,
    val _rid: String?,
    val _self: String?,
    val _etag: String?,
    val _attachments: String?,
    val _ts: Long?
)

data class OpsLogin(
    val email: String,
    val password: String,
)
